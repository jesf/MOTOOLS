#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;

int lanzamiento(int);
int main()
{
	int a;
	cin>>a;
	cout<<" si";
	int VC[a];
	VC[a]=lanzamiento(a);
	cout<<"Vector="<<endl;
	for(int i=0;i<a;i++)
	{
		cout<<VC[i]<<endl;
	}
	return 0;
	
}

int lanzamiento(int n)
{
	srand(time(NULL));
	int V[n]={0};
	for(int i=0;i<n;i++)
	{
		cin>>V[i];
	}
	return V[n];
}
