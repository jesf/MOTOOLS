#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace std;

int lanzar();


int main()
{
	srand(time(NULL));
	int num_jug;//numero de jugadores
	int num_dado=5;//numero de dados
	int again;//lanzar de nuevo;
	int fijar_dado[5];//fija un dado para que no se lance de nuevo
	cout<<"Ingrese numero de jugadores: ";
	cin>>num_jug;
	int contador_cartas[num_jug][6];
	int V[num_jug][num_dado];
	for(int i=0;i<num_jug;i++)
	{
		for(int k=0;k<5;k++)
		{
			fijar_dado[k]=0;
		}
		cout<<"lanza jugador "<<i+1<<endl;
		for(int j=0;j<3;j++)
		{
			cout<<"lanzamiento "<<j+1<<endl;
			for(int k=0;k<5;k++)
			{
				if(fijar_dado[k]==0) V[i][k]=rand()%6;
			}
			cout<<"su lanzamiento es: ";
			
			for(int k=0;k<5;k++)
			{
				cout<<V[i][k]<<" ";
			}
			
			if(j<2) {cout<<"Quiere lanzar de nuevo?"<<endl;cin>>again;}
			
			if (again==0 or j==2)
			{
				j=3;
				for(int k=0;k<5;k++)
				{
					switch(V[i][k])
					{
						case 0 : contador_cartas[i][0]++;break;
						case 1 : contador_cartas[i][1]++;break;
						case 2 : contador_cartas[i][2]++;break;
						case 3 : contador_cartas[i][3]++;break;
						case 4 : contador_cartas[i][4]++;break;
						case 5 : contador_cartas[i][5]++;break;
						default: break;
					}
				}
				
			}	
			else
			{
				cout<<"ponga en 1 los dados que quiere fijar:"<<endl;
				for(int k=0;k<5;k++)
				{
					cin>>fijar_dado[k];
				}				
			}
			cout<<"pruebaaaaa"<<endl;		
			
		}		
	}
	
}
